﻿/***
|''Name:''|WikiBarPlugin|
|''Version:''|1.2.0|
|''Source:''|[[AiddlyWiki|http://aiddlywiki.sourceforge.net]]|
|''Author:''|[[Arphen Lin|mailto:arphenlin@gmail.com]]|
|''Type:''|Plugin extension|
|''Required:''|TiddlyWiki 1.2.38+|
!Description
WikiBarPlugin is a toolbar that gives access to all of TiddlyWiki's formatting features with a few clicks. It's a handy tool for people who are not familiar with TiddlyWiki syntax.
!Support browser
*Firefox 1.0.7
!Revision history
*v1.2.0 (2005/11/21)
**New Features:
***User defined color palettes supported
####Get color palettes from [[ColorZilla Palettes|http://www.iosart.com/firefox/colorzilla/palettes.html]]. 
####Save the palette file(*.gpl) as a new tiddler and tag it with 'ColorPalettes', then you can use it in WikiBar.
***WikiBar style sheet supported
***Click on document to close current colorPicker, paletteSelector or aboutWikibar
*v1.1.1 (2005/11/03)
**Bugs fixed:
***"Not enough parameters!" message is displayed when the parameter includes "%+number", ex: "hello%20world!"
*v1.1.0 (2005/11/01)
**Bugs fixed:
***WikiBar overruns (reported by by "GeoffS" <gslocock@yahoo.co.uk>)
**New features:
***Insert a color code at the cursor. (Thanks to "RunningUtes" <RunningUtes@gmail.com>)
***Enable gradient macro. (Thanks to "RunningUtes" <RunningUtes@gmail.com>)
***Insert tiddler comment tags {{{/% ... %/}}}. (new feature supported by TiddlyWiki 1.2.37)
***Insert DateFormatString for {{{<<today>>}}} macro. (new feature supported by TiddlyWiki 1.2.37)
**Enhanced:
***Allow optional parameters in syntax.
**Bugs:
***"Not enough parameters!" message is displayed when the parameter includes "%+number", ex: "hello%20world!"
*v1.0.0 (2005/10/30)
**Initial release
!Code
***/
//{{{

version.extensions.WikiBar = {major: 1, minor: 2, revision: 0, date: new Date(2005,11,21)};

//------------------------------------------------------------------------------------------------
// the syntax will be applied on the current word
// params: editor, [[param1],[param2],...]
//------------------------------------------------------------------------------------------------
apl_wikibar_formatByWord = function(editor, params){

  clearMessage();
  
  if(!editor) return;
  
  repText = processSyntaxParams(this.syntax, params);
  if(!repText)  return;
    	
	var st = editor.scrollTop;
	var ss = editor.selectionStart;
	var se = editor.selectionEnd;
	
	var frontText= '';
	var selText  = '';
	var endText  = '';
	var fullText = editor.value;
	
	if(se>ss && ss>=0){   // has selection
	  frontText  = fullText.substring(0, ss);	// text before selection
	  selText	   = fullText.substring(ss,se);
	  endText    = fullText.substring(se, fullText.length);	// text behind selection
	}
	else if(ss==0 && (se==0 || se == fullText.length) ){  // no selection, cursor in begin
    endText    = fullText;	// text behind selection
	}
	else if(se==ss && ss>0){  // no selection, cursor in text
    frontText  = fullText.substring(0, ss);	// text before selection
    endText    = fullText.substring(se, fullText.length);	// text behind selection

	  //select a word
	  if( fullText.charAt(ss-1).match(/\W/gi) || fullText.charAt(ss).match(/\W/gi) ){ 
	    ;
	  }
	  else{ // cursor in text

      // find the lastest non-word position of frontText
      var m = frontText.match(/\W/gi);
      if(m){
        ss = frontText.lastIndexOf(m[m.length-1])+1;
      }
      else{ // not found
        ss = 0;          
      }
      
      
  	  // find the first non-word position of endText
      m = endText.match(/\W/gi);
      if(m){
        se += endText.indexOf(m[0]);
      }
      else{ // not found
        se = fullText.length;
      }

  	  // re-positioning
      frontText = fullText.substring(0, ss);	// text before selection
  	  endText   = fullText.substring(se, fullText.length);	// text behind selection
  	  selText   = fullText.substring(ss,se);
	    
	  }
	}
	
	if(selText.length>0)
		repText = repText.replace('user_text', selText);
		
	if(repText.indexOf('user_text')>=0 && this.hint)
		repText = repText.replace('user_text', this.hint);			  		
		
	editor.value = frontText + repText + endText;
	
	// re-positioning
	editor.selectionStart = ss;
	editor.selectionEnd   = ss + repText.length;
	editor.scrollTop      = st;
	
	editor.focus();
  
}

// params may be null, string or array
function processSyntaxParams(syntaxStr, params)
{
  try{

    var pcr = "AplWikibarPcr"; // percent character replacement
    var rx=null;
    var allParams=null;
    // replace parameter: %1,%2,...
    if(params!=null){
      if(typeof(params)=="object"){  // array
        for(i=0; i<params.length; i++){
          if(params[i]){
            // hide % character
            params[i] = params[i].replace(new RegExp('%',"g"), pcr).trim();
            rx = "(\\[%"+(i+1)+"\\])" + "|" + "(%"+(i+1)+")";
            syntaxStr = syntaxStr.replace(new RegExp(rx,"g"), params[i] );
          }
        }
        allParams = params.join(' ').trim();
      }
      else{ // string
        allParams = params.replace(new RegExp('%',"g"), pcr).trim();  // hide % character
        rx = /(\[%1{1}\])|(%1{1})/g;
        syntaxStr = syntaxStr.replace(rx, allParams);
      }    
    }
    
    // replace parameter: %N
    if(allParams)
      syntaxStr = syntaxStr.replace(new RegExp('%N{1}',"g"), allParams);
        
    // remove optional parameters
    rx=/\[%(([1-9]{1,}[0-9]{0,})|(N{1}))\]/g;
    syntaxStr = syntaxStr.replace(rx, '');
    
    // check if replaced ok
    rx=/%(([1-9]{1,}[0-9]{0,})|(N{1}))/g;
    if( syntaxStr.match(rx) ){
      throw "Not enough parameters! " + syntaxStr;
    }
    
    // recover % character
    syntaxStr=syntaxStr.replace(new RegExp(pcr,"g"), '%');
    
    return syntaxStr;
    
  } catch(ex){
//    displayMessage('processSyntaxParams(): '+ex);
    return null;
  }
}

//------------------------------------------------------------------------------------------------
// common format function
//------------------------------------------------------------------------------------------------
apl_wikibar_format = function(editor, params){

  clearMessage();
  
  if(!editor) return;
  
  repText = processSyntaxParams(this.syntax, params);
  if(!repText)  return;
	
	var st = editor.scrollTop;
	var ss = editor.selectionStart;
	var se = editor.selectionEnd;
	
//  	displayMessage(ss + ',' + se);
	
	var frontText= '';
	var endText  = '';
	var fullText = editor.value;
	
	if(se>ss && ss>=0){   // has selection
	  frontText  = fullText.substring(0, ss);	// text before selection
	  endText    = fullText.substring(se, fullText.length);	// text behind selection
	}
	else if(ss==0 && (se==0 || se == fullText.length) ){  // no selection, cursor in begin
    endText    = fullText;	// text behind selection
	}
	else if(se==ss && ss>0){  // no selection, cursor in text
    frontText  = fullText.substring(0, ss);	// text before selection
    endText    = fullText.substring(se, fullText.length);	// text behind selection
	}
	
	if(repText.indexOf('user_text')>=0 && this.hint)
		repText = repText.replace('user_text', this.hint);			  		
	
	editor.value = frontText + repText + endText;
	
	// re-positioning
	editor.selectionStart = ss;
	editor.selectionEnd   = ss + repText.length;
	editor.scrollTop      = st;
	
	editor.focus();

}


//------------------------------------------------------------------------------------------------
// if selected text, replace it
// else insert it
//------------------------------------------------------------------------------------------------
apl_wikibar_formatByCursor = function(editor, params){

  clearMessage();
  
  if(!editor) return;
  
  repText = processSyntaxParams(this.syntax, params);
  if(!repText)  return;
	
	var st = editor.scrollTop;
	var ss = editor.selectionStart;
	var se = editor.selectionEnd;
	
	var frontText= '';
	var endText  = '';
	var fullText = editor.value;
	
	if(se>ss && ss>=0){   // has selection
	  frontText  = fullText.substring(0, ss);	// text before selection
	  endText    = fullText.substring(se, fullText.length);	// text behind selection
	}
	else if(ss==0 && (se==0 || se == fullText.length) ){  // no selection, cursor in begin
    endText    = fullText;	// text behind selection
	}
	else if(se==ss && ss>0){  // no selection, cursor in text
    frontText  = fullText.substring(0, ss);	// text before selection
    endText    = fullText.substring(se, fullText.length);	// text behind selection
	}
	
	if(repText.indexOf('user_text')>=0 && this.hint)
		repText = repText.replace('user_text', this.hint);			  		
	
	editor.value = frontText + repText + endText;
	
	// re-positioning
	editor.selectionStart = ss;
	editor.selectionEnd   = ss + repText.length;
	editor.scrollTop      = st;
	
	editor.focus();
  
}

//------------------------------------------------------------------------------------------------
// the syntax will be applied on the current line
//------------------------------------------------------------------------------------------------
apl_wikibar_formatByLine = function(editor, params)
{

  clearMessage();
  
  if(!editor) return;
  
  repText = processSyntaxParams(this.syntax, params);
  if(!repText)  return;  	
  
  
	var st = editor.scrollTop;
	var ss = editor.selectionStart;
	var se = editor.selectionEnd;
	
	var frontText= '';
	var selText  = '';
	var endText  = '';
	var fullText = editor.value;
	
	if(se>ss && ss>=0){   // has selection
		if(this.byBlock){
	    frontText  = fullText.substring(0, ss);	// text before selection
	    selText		 = fullText.substring(ss,se);	// selection text
	    endText    = fullText.substring(se, fullText.length);	// text behind selection
		}
		else{
	  	se = ss;
		}
	}
	
  if(ss==0 && (se==0 || se == fullText.length) ){  // no selection, cursor in begin
    var m=fullText.match(/(\n|\r)/g);   // position of line-break
    if(m)
      se = fullText.indexOf(m[0]);
    else
      se = fullText.length;

    selText    = fullText.substring(0, se); 
    endText    = fullText.substring(se, fullText.length);	// text behind selection  
	}
	else if(se==ss && ss>0){  // no selection text, cursor in text
    frontText  = fullText.substring(0, ss);	// text before selection
    endText    = fullText.substring(se, fullText.length);	// text behind selection
    
    // find the last position of line-break in frontText
    var m = frontText.match(/(\n|\r)/g);  // position of line-break
    if(m){
      ss = frontText.lastIndexOf(m[m.length-1])+1;
    }
    else{ // not found
      ss = 0;          
    }
    
	  // find the first position of line-break in endText
    m = endText.match(/(\n|\r)/g);  // position of line-break
    if(m){
      se += endText.indexOf(m[0]);
    }
    else{ // not found
      se = fullText.length;
    }

	  // re-positioning
    frontText = fullText.substring(0, ss);	// text before selection
	  selText   = fullText.substring(ss,se);
	  endText   = fullText.substring(se, fullText.length);	// text behind selection
	}
	
	if(selText.length>0)
		repText = repText.replace('user_text', selText);
		
	if(repText.indexOf('user_text')>=0 && this.hint)
		repText = repText.replace('user_text', this.hint);			  	
		
	if(this.byBlock){		    
    // add extra line-breaks
    if( (frontText.charAt(frontText.length-1)!='\n') && ss!=0 )
    	repText = '\n' + repText;
    if( (endText.charAt(0)!='\n') || se==fullText.length)
    	repText += '\n';
	}
		
	editor.value = frontText + repText + endText;
	
	// re-positioning
	editor.selectionStart = ss;
	editor.selectionEnd   = ss + repText.length;
	editor.scrollTop      = st;
	
	editor.focus();

}

//------------------------------------------------------------------------------------------------
// the syntax will be applied on the table cell(if exist)
//------------------------------------------------------------------------------------------------
apl_wikibar_formatByTableCell = function(editor, params){

  clearMessage();
  
  if(!editor) return;
  
  repText = processSyntaxParams(this.syntax, params);
  if(!repText)  return;
    	
	var st = editor.scrollTop;
	var ss = editor.selectionStart;
	var se = editor.selectionEnd;
	
	var frontText= '';
	var selText  = '';
	var endText  = '';
	var fullText = editor.value;
	
	if(ss==0 || ss==fullText.length)
		throw "not valid cell!";
		
	se=ss;			
	
  frontText  = fullText.substring(0, ss);	// text before selection
  endText    = fullText.substring(se, fullText.length);	// text behind selection
  
  // find the last '|' position in frontText
  i=frontText.lastIndexOf("\n");
  j=frontText.lastIndexOf("|");
  if(i>j || j<0)
  	//throw "frontText not valid cell! " + i + "," + j;
  	throw "not valid cell!";
	
	ss = j+1;
				    	
  // find the first '|' position in endText
  i=endText.indexOf("\n");
  j=endText.indexOf("|");
  if(i<j || j<0)
  	//throw "endText not valid cell! " + i + "," + j;
  	throw "not valid cell!";
  
  se += j;
  
  // re-positioning
  frontText = fullText.substring(0, ss-1);	// text before selection
  selText   = fullText.substring(ss,se);
  endText   = fullText.substring(se+1, fullText.length);	// text behind selection

	if(this.name.substring(0,5)=="align"){
		selText = selText.trim();
		if(	selText==">" || selText=="~" || 
				selText.substring(0,8)=="bgcolor(" 
			)	// bypass special table code
			return;
	}
	
	if(selText.length>0)
		repText = repText.replace('user_text', selText);
		
	if(repText.indexOf('user_text')>=0 && this.hint)
		repText = repText.replace('user_text', this.hint);			  		
		
	editor.value = frontText + repText + endText;
	
	// re-positioning
	editor.selectionStart = ss;
	editor.selectionEnd   = ss + repText.length - 2;
	editor.scrollTop      = st;
	
	editor.focus();
  
}


//------------------------------------------------------------------------------------------------
// param: editor, button_pressed
//------------------------------------------------------------------------------------------------
apl_wikibar_selectColorPalette = function(editor, theTarget)
{
  if(!apl_wikibar_colorTool)  return;

	apl_wikibar_colorTool.createPaletteSelector(theTarget);
}

apl_wikibar_getColorCode = function(editor, theTarget)
{
  if(!apl_wikibar_colorTool)  return;
  
  apl_wikibar_colorTool.targetSyntax = this;
  apl_wikibar_colorTool.targetEditor = editor;
  apl_wikibar_colorTool.moveColorPicker(theTarget);  
}

apl_wikibar_getLinkUrl = function(editor)
{
  var url= prompt('Please enter the link target', this.param);
  if (url && url.trim().length>0)
    this.format(editor, url);
}

apl_wikibar_getTableRowCol = function(editor)
{
  var rc= prompt('Please enter rows x cols of the table', '2 x 3');
  if (!rc || (rc.trim()).length==0) return;
  
  var arr = rc.toUpperCase().split('X');
  if(arr.length != 2)   return;
  
  for(i=0; i<arr.length; i++)
    if(isNaN(arr[i].trim()))  return;
  
  rows = parseInt(arr[0].trim());
  cols = parseInt(arr[1].trim());
  
  txtTable='';
  for(r=0; r<rows; r++){
    for(c=0; c<=cols; c++)
      if(c==0)
        txtTable += '|';
      else
        txtTable += ' |';
      
    txtTable += '\n';
  }

  if(txtTable.trim().length>0)      
    this.format(editor, txtTable);
  
}

apl_wikibar_getMacroParam = function(editor)
{
	  var p = prompt('Please enter the parameters of ' + this.name + ' macro:' + 
	                 '\nSyntax: ' + this.syntax +
	                 '\n\nNote: '+
	                 '\n%1,%2,... - parameter needed'+ 
	                 '\n[%1] - optional parameter'+
	                 '\n%N   - more than one parameter(1~n)'+
	                 '\n[%N] - any number of parameters(0~n)'+
	                 '\n\nPS:'+
	                 '\n Parameters should be seperated with space character'+
	                 '\n Use "" to wrap the parameter that includes space character, ex: "hello world"'+
	                 '\n Input the word(null) for the optional parameter ignored',
	                 (this.param?this.param:'') );
	  
    if(p==null)  return;

    p=p.readMacroParams();
    for(i=0;i<p.length;i++){
      var s=p[i].trim();
      if(s.indexOf(' ')>0)
        p[i]="'"+s+"'";
      if(s.toLowerCase()=="null")
        p[i]=null;
    }
    
    this.format(editor, p);
      
}


//------------------------------------------------------------------------------------------------
// hijack createTiddlerEditor() to create WikiBar
//------------------------------------------------------------------------------------------------
window.apl_wikibar_createTiddlerEditor = window.createTiddlerEditor;
window.createTiddlerEditor = function (title)
{
  // call original function
  apl_wikibar_createTiddlerEditor(title);
    
  // create wiki-bar
  apl_wikibar_createWikibar(title);
}

function apl_wikibar_createWikibar(title){

    // insert wikisyntax toolbar before editorBodyXXX
    var theEditor = document.getElementById("editorWrapper" + title);
    var theBodyBox = document.getElementById("editorBody" + title);
    
    // create Wikibar
    var theWikibar = createTiddlyElement(theEditor,"div","editorWikibar" + title,"wikibar",null);	// CSS: .wikibar

    theEditor.insertBefore(theWikibar,theBodyBox);
    
    // create tool buttons
    
    // single button
    
    // about
    var btn = apl_wikibar_createWikibarButton(theWikibar, "&copy;", "about WikiBarPlugin", apl_wikibar_onClickAbout, title);
    if(btn) btn.id = "apl_wikibar_btn_about";

		// preview
    btn = apl_wikibar_createWikibarButton(theWikibar, "&infin;", "preview the tiddler", apl_wikibar_onClickPreview, title);
    if(btn) btn.id = "apl_wikibar_btn_preview";
    
    // formattings
    for(i=0; i<apl_wikibar_syntaxes.formattings.length; i++){
      var syntaxObj = apl_wikibar_syntaxes.formattings[i];
      syntax_desc = "apl_wikibar_syntaxes.formattings["+i+"]";
      if(syntaxObj.symbol)
      	apl_wikibar_createWikibarButton(theWikibar, syntaxObj.symbol, syntaxObj.tip, apl_wikibar_onClickWikibarButton, title, syntax_desc);
    	else
      	apl_wikibar_createWikibarButton(theWikibar, syntaxObj.name, syntaxObj.tip, apl_wikibar_onClickWikibarButton, title, syntax_desc);
    }
    
    // dropdown menu
    apl_wikibar_createWikibarButton(theWikibar, "color", "Color", apl_wikibar_onClickWikibarMenu, title, null, "apl_wikibar_syntaxes.colors");
    apl_wikibar_createWikibarButton(theWikibar, "link", "Link", apl_wikibar_onClickWikibarMenu, title, null, "apl_wikibar_syntaxes.links");
    apl_wikibar_createWikibarButton(theWikibar, "Hn", "Heading", apl_wikibar_onClickWikibarMenu, title, null, "apl_wikibar_syntaxes.headings");
    apl_wikibar_createWikibarButton(theWikibar, "list", "List", apl_wikibar_onClickWikibarMenu, title, null, "apl_wikibar_syntaxes.lists");
    apl_wikibar_createWikibarButton(theWikibar, "paragraph", "Paragraph format", apl_wikibar_onClickWikibarMenu, title, null, "apl_wikibar_syntaxes.paragraphs");
    apl_wikibar_createWikibarButton(theWikibar, "table", "Table", apl_wikibar_onClickWikibarMenu, title, null, "apl_wikibar_syntaxes.tables");
    apl_wikibar_createWikibarButton(theWikibar, "plugin", "Plugin design", apl_wikibar_onClickWikibarMenu, title, null, "apl_wikibar_syntaxes.plugins");
    apl_wikibar_createWikibarButton(theWikibar, "macro", "Macro", apl_wikibar_onClickWikibarMenu, title, null, "apl_wikibar_syntaxes.macros");
    apl_wikibar_createWikibarButton(theWikibar, "date", "Date format string", apl_wikibar_onClickWikibarMenu, title, null, "apl_wikibar_syntaxes.dates");
    apl_wikibar_createWikibarButton(theWikibar, "html", "HTML", apl_wikibar_onClickWikibarMenu, title, null, "apl_wikibar_syntaxes.htmls");
    
}

//------------------------------------------------------------------------------------------------
// create wikibar button
// ps. 
// if single button: syntax_objs=null, syntax_obj needed
// if group button: syntax_objs needed, syntax_obj=null
//------------------------------------------------------------------------------------------------
function apl_wikibar_createWikibarButton(theToolbar, theText, theTooltip, theAction, title, syntax_obj, syntax_objs)
{
    if(!theToolbar)  return null;
    
    // call system function to add a button
    //createTiddlyButton(theParent,theText,theTooltip,theAction,theClass,theId,theAccessKey)
    var theButton = createTiddlyButton(theToolbar, theText, theTooltip, theAction, "button");
    if(!theButton) return null;

//    insertSpacer(theToolbar);
    
    // fix the wikibar overrun bug
  	theToolbar.appendChild( document.createTextNode("\n") );
  	
		theButton.innerHTML = theText;	// html is allowed here, ex: "<b>B</b>"

		// add parameters to theButton, those parameters will be used on onclick event
		// setAttribute() only accepts string variable, object is not allowed!
		// we'll use eval() to convert string to object, refer to apl_wikibar_onClickWikibarButton()
		if(title)
		  theButton.setAttribute("tiddler_title", title);
		  
    if(syntax_objs)
		  theButton.setAttribute("syntax_objs", syntax_objs);

    if(syntax_obj)
		  theButton.setAttribute("syntax_obj", syntax_obj);
		  
  	return theButton;
  	
  
}

function apl_wikibar_getComplementColor(c)
{
  n=parseInt(c.replace('#','0x'));
  nc=0xffffff-n;
  s = nc.toString(16);
  if(s.length<6)
    for(i=0;i<6-s.length;i++)
      s ='0'+s;
  return '#'+s;      
}

function apl_wikibar_numToHexColor(n)
{
  if(typeof(n)=='number' && (n>=0 && n<=255)) {
  		s = n.toString(16).toUpperCase();
  		return ((s.length==1)? '0'+s : s);
  	}
	
	return null;
}

//------------------------------------------------------------------------------------------------
// button(<a>) may have other tags, ex: <a><b>B</b></a>
// when we click the button, the apl_wikibar_onClickWikibarButton event may be received by the childNodes of <a>
// so we try to look up to the button object(<a>), as <a> has the parameters we need
//------------------------------------------------------------------------------------------------
function apl_wikibar_resolveClickButton(obj)
{
  if (obj.id=="tiddlerDisplay")   // search until tiddlerDisplay is reached
    return null;
  
  if(obj.hasAttributes()){
    if(obj.getAttribute("tiddler_title"))
      return obj;
    else
      return apl_wikibar_resolveClickButton(obj.parentNode); // search the parent
  }
  else{
    return apl_wikibar_resolveClickButton(obj.parentNode);  // search the parent
  }
}


function apl_wikibar_switchWikibar(wikibar, visible)
{
  if(!wikibar)  return;
  
  var pv=null;
  // hide other buttons
  for(i=0; i<wikibar.childNodes.length; i++){ 
    try{
      var theButton = wikibar.childNodes[i];

      if(theButton.id == "apl_wikibar_btn_preview") 
        pv=theButton;

      if(theButton.id != "apl_wikibar_btn_about" && theButton.id != "apl_wikibar_btn_preview")
        theButton.style.display = visible ? "": "none";
      
    }catch(ex){
      ;	// ignore object that doesn't has style
    }
  }
  
  if(!pv) return;
  
  // update the caption of preview button
  if(visible){
    pv.innerHTML = "&infin;";
    pv.setAttribute("title", "show previewer");
  }
  else{
    pv.innerHTML = "&larr;";
    pv.setAttribute("title", "back to editor");
  }
  
}

function apl_wikibar_displayAboutBox(theAbout, theTarget)
{

  if(!theAbout || !theTarget) return;
  
	var rootLeft = findPosX(theTarget);
  var rootTop = findPosY(theTarget);
  var rootHeight = theTarget.offsetHeight;
  
  var popupLeft = rootLeft;
  var popupTop = rootTop + rootHeight;
  
  var popupWidth = theAbout.offsetWidth;
  
  var winWidth = findWindowWidth();
  if(popupLeft + popupWidth > winWidth)
	  popupLeft = winWidth - popupWidth;
		
  theAbout.style.left = popupLeft + "px";
  theAbout.style.top = popupTop + "px";
  theAbout.style.display = "block";
  
}

function apl_wikibar_onClickAbout(e)
{
	if (!e) var e = window.event;
	var theTarget = resolveTarget(e);
	if(!theTarget) return(false);
	
  
  // check if already exist
  var theAbout = document.getElementById("aboutWikibar");
  
  if(theAbout){  // switch theAbout
  	relateTo = theAbout.getAttribute("relateTo");
  	if(relateTo == theTarget.parentNode.id){
    	theAbout.style.display = (theAbout.style.display=="block")? "none" : "block";
  	}
  	else{
  		theAbout.setAttribute("relateTo", theTarget.parentNode.id);
  		apl_wikibar_displayAboutBox(theAbout, theTarget);
  	}
  }
  else{	// create theAbout box
    theAbout = document.createElement("div");
    theAbout.setAttribute("id", "aboutWikibar");	// CSS: #aboutWikibar
    theAbout.setAttribute("class", "viewer");
    ver = version.extensions.WikiBar.major + "." + version.extensions.WikiBar.minor + "." + version.extensions.WikiBar.revision;
    theAbout.innerHTML = 	'<center>WikiBarPlugin Version '+ver+'<br></center><hr><ul>'+
    											'<li>Author: <a href="mailto:arphenlin@gmail.com">Arphen Lin</a></li>'+
    											'<li>Web: <a href="http://aiddlywiki.sourceforge.net/" target="new">AiddlyWiki</a></li>'+
    											'</ul>';
		theAbout.onclick = function(){
													document.getElementById("aboutWikibar").style.display="none";
												};											
    theAbout.setAttribute("relateTo", theTarget.parentNode.id);
    
    document.body.appendChild(theAbout);
    
    apl_wikibar_displayAboutBox(theAbout, theTarget);
  }
  
	e.cancelBubble = true;
	if (e.stopPropagation) e.stopPropagation();
	return(false);	
}

function apl_wikibar_onClickPreview(e)
{
	if (!e) var e = window.event;
	var theTarget = resolveTarget(e);
	if(!theTarget) return(false);
	
  var wikibar = theTarget.parentNode;
  if(!wikibar)  return;
  
  title = wikibar.id.substring(13, wikibar.id.length); // "editorWikibar"+title
  var editorWrapper = document.getElementById( "editorWrapper"+title);

	var editor= document.getElementById("editorBody"+title);

  // check if already exist
  var previewer = document.getElementById("previewer"+title);
  if(previewer){  // switch previewer
    if(previewer.style.display=="block"){
      previewer.style.display = "none";
      editor.style.display = "block";
    }
    else{
      previewer.innerHTML = ''; // clear the contents
      wikify(editor.value, previewer, null, null);  // refresh the contents
      previewer.style.display = "block";
      editor.style.display = "none";
    }
  }
  else{	// create previewer
    previewer = document.createElement("div");
    previewer.setAttribute("id", "previewer"+title);
    previewer.style.height = (editor.offsetHeight) + "px";
    previewer.setAttribute("class", "viewer");
    previewer.setAttribute("class", "previewer");
    editorWrapper.insertBefore(previewer, editor);
    
    wikify(editor.value, previewer, null, null);
    
    // hide editor
    editor.style.display = "none";
  }
  
  apl_wikibar_switchWikibar(wikibar, (editor.style.display=="block") );
  

	e.cancelBubble = true;
	if (e.stopPropagation) e.stopPropagation();
	return(false);	
  
}


//------------------------------------------------------------------------------------------------
// onclick event handler
//------------------------------------------------------------------------------------------------
function apl_wikibar_onClickWikibarButton(e)
{
	if (!e) var e = window.event;
	var theTarget = apl_wikibar_resolveClickButton(resolveTarget(e));
	if(!theTarget) return(false);
	
	title = theTarget.getAttribute("tiddler_title");
	
	var editor = document.getElementById("editorBody"+title);
  if(!editor) return;
  
  var syntax = null;
  cmd = "syntax = " + theTarget.getAttribute("syntax_obj");
	eval(cmd);
	if(!syntax) return;
	
	if(syntax.needParam)
	  syntax.needParam(editor, theTarget);
	else
	  syntax.format(editor);
  		
	e.cancelBubble = true;
	if (e.stopPropagation) e.stopPropagation();
	return(false);	

}


//------------------------------------------------------------------------------------------------
// create drop-down menu
//------------------------------------------------------------------------------------------------
function apl_wikibar_onClickWikibarMenu(e)
{
	if(!e) var e = window.event;
	var theTarget = resolveTarget(e);   // = <span>, the object we click on
	
  title = theTarget.getAttribute("tiddler_title");
  
  // retrieve the string and eval() it 
  my_syntaxes = theTarget.getAttribute("syntax_objs");
  var items=null;
  cmd = "items = "+my_syntaxes;
  eval(cmd);
	if(!items) return;

	var popup = createTiddlerPopup(this);
	if(!popup) return;

	for (i=0; i<items.length; i++){
	  var theItem = createTiddlyButton(
                      createTiddlyElement(popup, "li"),
                      items[i].name,
                      items[i].tip,
                      apl_wikibar_onClickWikibarButton
                      );

		theItem.setAttribute("syntax_obj", my_syntaxes + "["+i+"]");
		theItem.setAttribute("tiddler_title", title);
	}

	scrollToTiddlerPopup(popup,false);
  	
  
	e.cancelBubble = true;
	if (e.stopPropagation) e.stopPropagation();
	return(false);	
  
}


//------------------------------------------------------------------------------------------------
// apl_wikibar_ColorTool class
//------------------------------------------------------------------------------------------------
function apl_wikibar_ColorTool(theAction){
  
  // 16x16 colors
  this.defaultPaletteName = 'default';
  this.defaultColumns = 16;
  this.defaultPalette = [  
    "#FFFFFF","#DDDDDD","#CCCCCC","#BBBBBB","#AAAAAA","#999999","#666666","#333333","#111111","#000000","#FFCC00","#FF9900","#FF6600","#FF3300","#CC3300","#CC0033",
    "#99CC00","#99DD00","#99EE00","#EE9900","#DD9900","#CC9900","#FFCC33","#FFCC66","#FF9966","#FF6633","#660000","#990000","#CC0000","#FF0000","#FF3366","#FF0033",
    "#CCFF00","#CCFF33","#333300","#666600","#999900","#CCCC00","#FFFF00","#CC9933","#CC6633","#330000","#993333","#CC3333","#FF3333","#CC3366","#FF6699","#FF0066",
    "#99FF00","#CCFF66","#99CC33","#666633","#999933","#CCCC33","#FFFF33","#996600","#993300","#663333","#CC6666","#FF6666","#990033","#CC3399","#FF66CC","#FF0099",
    "#66FF00","#99FF66","#66CC33","#669900","#999966","#CCCC66","#FFFF66","#996633","#663300","#996666","#FF9999","#FF3399","#CC0066","#990066","#FF33CC","#FF00CC",
    "#33FF00","#66FF33","#339900","#66CC00","#99FF33","#CCCC99","#FFFF99","#CC9966","#CC6600","#CC9999","#FF99CC","#CC6699","#993366","#660033","#CC0099","#330033",
    "#00CC00","#33CC00","#336600","#669933","#99CC66","#CCFF99","#FFFFCC","#FFCC99","#FF9933","#FFCCCC","#CC99CC","#996699","#993399","#990099","#663366","#660066",
    "#006600","#33CC33","#66CC66","#00FF00","#33FF33","#66FF66","#99FF99","#CCFFCC","#99CCFF","#FFCCFF","#FF99FF","#FF66FF","#FF33FF","#FF00FF","#CC66CC","#CC33CC",
    "#003300","#336633","#009900","#339933","#669966","#99CC99","#CCFFFF","#3399FF","#6699CC","#CCCCFF","#CC99FF","#9966CC","#663399","#330066","#9900CC","#CC00CC",
    "#00FF33","#00CC33","#006633","#339966","#66CC99","#99FFCC","#99CCCC","#0066CC","#336699","#9999FF","#9999CC","#9933FF","#6600CC","#660099","#CC33FF","#CC00FF",
    "#00FF66","#33FF66","#009933","#00CC66","#33FF99","#99FFFF","#669999","#003366","#003399","#6666FF","#6666CC","#666699","#330099","#9933CC","#CC66FF","#9900FF",
    "#00FF99","#66FF99","#33CC66","#009966","#66FFFF","#66CCCC","#336666","#006699","#3366CC","#3333FF","#3333CC","#333399","#333366","#6633CC","#9966FF","#6600FF",
    "#00FFCC","#66FFCC","#33CC99","#33FFFF","#33CCCC","#339999","#003333","#3399CC","#6699FF","#0000FF","#0000CC","#000099","#000066","#000033","#6633FF","#3300FF",
    "#00CC99","#33FFCC","#00FFFF","#00CCCC","#009999","#006666","#33CCFF","#66CCFF","#0099CC","#3366FF","#00CCFF","#0099FF","#0066FF","#0033FF","#0033CC","#3300CC"
  ];

	this.paletteName = this.defaultPaletteName; 
  this.palette = this.defaultPalette;
  this.columns = this.defaultColumns;
  
	this.colorPicker = null;		// div object

  this.targetSyntax = null;   // the syntax object that called apl_wikibar_ColorTool
  this.targetEditor = null;   // the editor object that will be applied selected color
  this.theAction = theAction;
  
//  this.createColorPicker();

}

apl_wikibar_ColorTool.prototype.renderColorPalette = function() 
{

	if(this.paletteName==this.defaultPaletteName){
		this.palette=this.defaultPalette;
		this.columns=this.defaultColumns;
		return;
	}
	
	tiddlerText = (store.getTiddlerText(this.paletteName, '')).trim();
	if(tiddlerText.length==0) return;
	var cpContents = tiddlerText.split('\n');
	
	var colors=[];
	columns = this.defaultColumns;
	var tmpArray=null;
	errCount=0;
	for(i=0; i<cpContents.length; i++){
		cpLine=cpContents[i].trim();

    if( (cpLine==null) || (cpLine.length==0) || (cpLine.charAt(0) == '#') ) continue;
		
		if(cpLine.substring(0,8).toLowerCase()=='columns:'){
			tmpArray = cpLine.split(':');
			try{
				columns = parseInt(tmpArray[1]);
			}catch(ex){
				columns = this.defaultColumns;
			}
		}else{
			tmpArray = cpLine.replace('\t', ' ').split(/[ ]{1,}/);
			
			try{
				color='';
				for(j=0; j<3; j++){
          c=parseInt(tmpArray[j].trim());
          if(isNaN(c)){
						break; // for
          }else{
						c=apl_wikibar_numToHexColor(c);
						if(c==null) break;
            color+=c;
					}
				} // for(j)
				
				if(color.length==6){
					colors.push('#'+color);
				}	else {
					throw 'error';
				}
				
			}catch(ex){
				//displayMessage('error line #'+i+': ' + cpLine);
				;	// ignore invalid record
			}
			
		} // else
		
	} // for(i)
	
	if(colors.length>0){
		this.palette = colors;
		this.columns = columns;
	}else{
		throw 'renderColorPalette(): No color defined in the palette.';
	}
	
}

apl_wikibar_ColorTool.prototype.showColorPicker = function() 
{
  if(this.colorPicker){
    this.colorPicker.style.display = "block";
  }
  
  this.closePaletteSelector();
}

apl_wikibar_ColorTool.prototype.hideColorPicker = function() 
{
  if(this.colorPicker){
    this.colorPicker.style.display = "none";
  }
}


apl_wikibar_ColorTool.prototype.moveColorPicker = function(theTarget)
{
  if(!this.colorPicker)
  	this.createColorPicker();
  	
	var cp = this.colorPicker;  	
  
	var rootLeft = findPosX(theTarget);
  var rootTop = findPosY(theTarget);
  var rootHeight = theTarget.offsetHeight;
  
  var popupLeft = rootLeft;
  var popupTop = rootTop + rootHeight;
  
  var popupWidth = cp.offsetWidth;
  
  var winWidth = findWindowWidth();
  if(popupLeft + popupWidth > winWidth)
	  popupLeft = winWidth - popupWidth;
		
  cp.style.left = popupLeft + "px";
  cp.style.top = popupTop + "px";
  this.showColorPicker();
  
}

apl_wikibar_ColorTool.prototype.createColorPicker = function(theTarget, palette) 
{
    if(!this.theAction) return;
    
    if(palette)	this.paletteName=palette;

		this.renderColorPalette();
		
    // create div
		this.colorPicker = document.createElement("div");
		this.colorPicker.setAttribute("id","colorPicker");	//CSS: #colorPicker
		document.body.appendChild(this.colorPicker);

    // create table
    var theTable = document.createElement("table");
    this.colorPicker.appendChild(theTable);

    // header row
    var theTR = document.createElement("tr");
		theTable.appendChild(theTR);
		var theTD = document.createElement("td");
		theTD.setAttribute("colspan",this.columns);
		theTD.setAttribute("class", "header");	//CSS: #colorPicker .header
		theTD.innerHTML = this.paletteName;
    theTR.appendChild(theTD);
    
    // create tr/td
    for(i=0; i<this.palette.length; i++){
      // create new row
      if((i%this.columns)==0){  // 16x16
        theTR = document.createElement("tr");
        theTable.appendChild(theTR);
      }

      var theTD = document.createElement("td");
      if(this.palette[i].trim() == '')
        theTD.setAttribute("bgcolor", "white");
      else
        theTD.setAttribute("bgcolor", this.palette[i]);
      theTD.setAttribute("class", "cell");	//CSS: #colorPicker .cell
      theTD.onclick = this.theAction;
      theTD.onmouseover = apl_wikibar_onMouseOverColor;
      theTR.appendChild(theTD);
    }
    
    // pad
    rest = this.palette.length % this.columns;
    if(rest>0){
      var theTD = document.createElement("td");
			theTD.setAttribute("colspan",this.columns-rest);
      theTD.setAttribute("bgcolor", "black");
      theTR.appendChild(theTD);
    }
    
    // color info row
    theTR = document.createElement("tr");
		theTable.appendChild(theTR);
		theTD = document.createElement("td");
		theTD.setAttribute("colspan",this.columns);
		theTD.setAttribute("id", "colorPickerInfo");	//CSS: #colorPickerInfo
    theTR.appendChild(theTD);    

// 		//other palette row
//    theTR = document.createElement("tr");
//		theTable.appendChild(theTR);
//		var theTD = document.createElement("td");
//		theTD.setAttribute("colspan",this.columns);
//		theTD.setAttribute("class", "button");	//CSS: #colorPicker .button
//    theTD.onclick = function(){	apl_wikibar_selectColorPalette(null, apl_wikibar_colorTool.colorPicker); };
//		theTD.innerHTML = 'other palette...';
//    theTR.appendChild(theTD);

//    // bottom row
//    theTR = document.createElement("tr");
//		theTable.appendChild(theTR);
//		var theTD = document.createElement("td");
//		theTD.setAttribute("colspan",this.columns);
//		theTD.setAttribute("class", "button");	//CSS: #colorPicker .button
//    theTD.onclick = function(){	apl_wikibar_colorTool.hideColorPicker(); };
//		theTD.innerHTML = 'close';
//    theTR.appendChild(theTD);
		
}

apl_wikibar_ColorTool.prototype.closePaletteSelector = function() 
{
	paletteSelector = document.getElementById("paletteSelector");
	if(paletteSelector)
		document.body.removeChild(paletteSelector);
}

apl_wikibar_ColorTool.prototype.createPaletteSelector = function(theTarget)
{
	var cpTiddlers = store.getTaggedTiddlers("ColorPalettes");
	if(!cpTiddlers) return;
	
	var palettes=[];
	palettes.push(this.defaultPaletteName);
	for(i=0; i<cpTiddlers.length; i++)
		palettes.push(cpTiddlers[i].title.trim());
	
	// check if exist
	var paletteSelector = document.getElementById("paletteSelector");
	if(paletteSelector)
		document.body.removeChild(paletteSelector);

  // create paletteSelector
	paletteSelector = document.createElement("div");
	paletteSelector.setAttribute("id","paletteSelector");	// CSS: #paletteSelector
	document.body.appendChild(paletteSelector);

  // create table
  var theTable = document.createElement("table");
  paletteSelector.appendChild(theTable);
  
  // create tr/td
	var theTR=null;
  for(i=0; i<palettes.length; i++){
    // create new row
    theTR = document.createElement("tr");
    theTable.appendChild(theTR);

    var theTD = document.createElement("td");
    theTD.setAttribute("palette", palettes[i]);
    if(palettes[i]==apl_wikibar_colorTool.paletteName){
	    theTD.setAttribute("class", "selected");	// CSS: #paletteSelector .selected
    }else{
    	theTD.setAttribute("class", "unSelected");	// CSS: #paletteSelector .unSelected
    }
    theTD.onclick = apl_wikibar_onSelectPalette;
    theTD.innerHTML = palettes[i];
    theTR.appendChild(theTD);
  }
  
//  // bottom row
//  theTR = document.createElement("tr");
//	theTable.appendChild(theTR);
//	var theTD = document.createElement("td");
//	theTD.setAttribute("class", "button");	// CSS: #paletteSelector .button
//  theTD.onclick = apl_wikibar_colorTool.closePaletteSelector;
//	theTD.innerHTML = 'close';
//  theTR.appendChild(theTD);
  
  // set position
	rootLeft = findPosX(theTarget);
  rootTop = findPosY(theTarget);
  popupLeft = rootLeft;
  popupTop = rootTop;

  if(theTarget != apl_wikibar_colorTool.colorPicker){
		rootHeight = theTarget.offsetHeight;
  	popupTop += rootHeight;
  
	  popupWidth = paletteSelector.offsetWidth;
	  
	  winWidth = findWindowWidth();
	  if(popupLeft + popupWidth > winWidth)
	  	popupLeft = winWidth - popupWidth;
	}
		
  paletteSelector.style.left = popupLeft + "px";
  paletteSelector.style.top = popupTop + "px";
  paletteSelector.style.display = "block";    
  
  apl_wikibar_colorTool.hideColorPicker();
		
}


//------------------------------------------------------------------------------------------------
// do on select a color
//------------------------------------------------------------------------------------------------
function apl_wikibar_onSelectColor(e) 
{
	if (!e) var e = window.event;
	var theTarget = resolveTarget(e); 
	if(!theTarget) return(false);

	if(!apl_wikibar_colorTool)  return;
	
  // get the color
  color = theTarget.getAttribute("bgcolor");
  if(!color)  return;
  
  // close it
  apl_wikibar_colorTool.hideColorPicker();
  
  if(apl_wikibar_colorTool.targetSyntax && apl_wikibar_colorTool.targetEditor)
    apl_wikibar_colorTool.targetSyntax.format(apl_wikibar_colorTool.targetEditor, color);
      
	e.cancelBubble = true;
	if (e.stopPropagation) e.stopPropagation();
	return(false);	
}

function apl_wikibar_onMouseOverColor(e) 
{
	if (!e) var e = window.event;
	var theTarget = resolveTarget(e);
	if(!theTarget) return(false);

	if(!apl_wikibar_colorTool)  return;
	
  // get the color  	
  color = theTarget.getAttribute("bgcolor");
  if(!color)  return;
  
  td=document.getElementById("colorPickerInfo");
	if(!td) return;
	
	td.setAttribute("bgcolor", color);
	td.innerHTML = '<span style="color:#000;">'+color+'</span>&nbsp;&nbsp;&nbsp;' +
	               '<span style="color:#fff;">'+color+'</span>';

	e.cancelBubble = true;
	if (e.stopPropagation) e.stopPropagation();
	return(false);	
	
}

function apl_wikibar_onDocumentClick(e)
{
	if (!e) var e = window.event;
	var theTarget = resolveTarget(e);  
	if(!theTarget) return(false);

	// 1-CAPTURING_PHASE; 2-AT_TARGET; 3-BUBBLING_PHASE
	if(e.eventPhase == undefined || e.eventPhase == Event.BUBBLING_PHASE || e.eventPhase == Event.AT_TARGET){
		apl_wikibar_colorTool.hideColorPicker();
		apl_wikibar_colorTool.closePaletteSelector();
		var theAbout = document.getElementById("aboutWikibar");
		if(theAbout)	theAbout.style.display="none";
	}
	
	return true;
}


function apl_wikibar_onSelectPalette(e) 
{
	clearMessage();
  
	if (!e) var e = window.event;
	var theTarget = resolveTarget(e); 
	if(!theTarget) return(false);
	
	theTarget.setAttribute("class", "selected");
	
  // get the palette name
	palette = theTarget.getAttribute("palette");
  if(!palette)  return;
  
	// recreate colorPicker
	oldPaletteName = apl_wikibar_colorTool.paletteName;
	if(oldPaletteName != palette){
		try{
			apl_wikibar_colorTool.createColorPicker(theTarget, palette);
			displayMessage('Palette "'+palette+'" ('+ apl_wikibar_colorTool.palette.length +' colors) is selected');
		}catch(ex){
			errMsg = ex;
			if(errMsg.substring(0,18)=='renderColorPalette'){
				displayMessage('Invalid palette "' + palette + '", please check it out!');
				apl_wikibar_colorTool.createColorPicker(theTarget, oldPaletteName);
			}
		}
	}
	
	// close
	apl_wikibar_colorTool.closePaletteSelector();
		
	e.cancelBubble = true;
	if (e.stopPropagation) e.stopPropagation();
	return(false);
   
}


//------------------------------------------------------------------------------------------------
// global variables: color picker
//------------------------------------------------------------------------------------------------
var apl_wikibar_colorTool = new apl_wikibar_ColorTool(apl_wikibar_onSelectColor);

//------------------------------------------------------------------------------------------------
// global variables: syntax object
// 
// parameter syntax: %1,%2,... - parameter needed, [%1] - optional parameter
//                   %N        - more than one parameter(1~n)
//                   [%N]      - any parameter(0~n)
//------------------------------------------------------------------------------------------------
var apl_wikibar_syntaxes = {
  formattings: [
		{
			name: 	"ignore",
			tip:    "ignore wiki word",
			symbol: "~",
			syntax: "~user_text",
			hint:   "wiki_word",
			format:	apl_wikibar_formatByWord
		},
		{
			name: 	"bold",
			tip:    "bolder text",
			symbol: "<strong>B</strong>",
			syntax: "''user_text''",
			hint:		"bold_text",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"italic",
			tip:    "italic text",
			symbol: "<em>I</em>",
			syntax: "//user_text//",
			hint:		"italic_text",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"underline",
			tip:    "underline text",
			symbol: "<u>U</u>",
			syntax: "__user_text__",
			hint:		"underline_text",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"strike",
			tip:    "strikethrough text",
			symbol: "<strike>S</strike>",
			syntax: "==user_text==",
			hint:		"strikethrough_text",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"sup",
			tip:    "superscript text",
			symbol: "X<sup>2</sup>",
			syntax: "^^user_text^^",
			hint:		"superscript_text",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"sub",
			tip:    "subscript text",
			symbol: "X<sub>2</sub>",
			syntax: "~~user_text~~",
			hint:		"subscript_text",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"comment",
			tip:    "comment text",
			symbol: "/%",
			syntax: "/%user_text%/",
			hint:		"comment_text",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"monospaced",
			tip:    "monospaced text",
			symbol: "<code>mono</code>",
			syntax: "{{{user_text}}}",
			hint:		"monospaced_text",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"line",
			tip:    "horizontal line",
			symbol: "&mdash;",
			syntax: "\n----\n",
			format: apl_wikibar_formatByCursor
		},
		{
			name: 	"crlf",
			tip:    "line break",
			symbol: "&para;",
			syntax: "\n",
			format: apl_wikibar_formatByCursor
		}
  ],  // formattings
  colors: [
		{
			name: 	"highlight",
			tip:    "highlight text",
			syntax: "@@user_text@@",
			hint:		"highlight_text",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"palette",
			tip:    "select palette",
			syntax: "",
			needParam: apl_wikibar_selectColorPalette
		},
		{
			name: 	"color",
			tip:    "text color",
			hint:		"your_text",
			syntax: "@@color(%1):user_text@@",
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getColorCode
		},
		{
			name: 	"bgcolor",
			tip:    "background color",
			hint:		"your_text",
			syntax: "@@bgcolor(%1):user_text@@",
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getColorCode
		},
    {
      name:   "colorcode",
      tip:    "insert colorcode",
      syntax: "%1",
      format: apl_wikibar_formatByCursor,
      needParam: apl_wikibar_getColorCode
    }		
  ],  // colors
  lists:[
		{
			name: 	"bullet",
			tip:    "bullet point",
			syntax: "*user_text",
			hint:		"bullet_text",
			format: apl_wikibar_formatByLine
		},
		{
			name: 	"numbered",
			tip:    "numbered list",
			syntax: "#user_text",
			hint:		"numbered_text",
			format: apl_wikibar_formatByLine
		}
  ],  // lists
  headings:[
		{
			name: 	"Heading 1",
			tip:    "Heading 1",
			syntax: "!user_text",
			hint:		"heading_1",
			format: apl_wikibar_formatByLine
		},
		{
			name: 	"Heading 2",
			tip:    "Heading 2",
			syntax: "!!user_text",
			hint:		"heading_2",
			format: apl_wikibar_formatByLine
		},
		{
			name: 	"Heading 3",
			tip:    "Heading 3",
			syntax: "!!!user_text",
			hint:		"heading_3",
			format: apl_wikibar_formatByLine
		},
		{
			name: 	"Heading 4",
			tip:    "Heading 4",
			syntax: "!!!!user_text",
			hint:		"heading_4",
			format: apl_wikibar_formatByLine
		},
		{
			name: 	"Heading 5",
			tip:    "Heading 5",
			syntax: "!!!!!user_text",
			hint:		"heading_5",
			format: apl_wikibar_formatByLine
		}
  ],  // headings
  paragraphs:[
		{
			name: 	"comment by line",
			tip:    "line comment",
			syntax: "/%user_text%/",
			hint:		"comment_text",
			format: apl_wikibar_formatByLine
		},
		{
			name: 	"comment by block",
			tip:    "block comment",
			syntax: "/%\nuser_text\n%/",
			hint:		"comment_text",
			byBlock: true,			
			format: apl_wikibar_formatByLine
		},
		{
			name: 	"monospaced by line",
			tip:    "line monospaced",
			syntax: "{{{\nuser_text\n}}}",
			hint:		"monospaced_text",
			format: apl_wikibar_formatByLine
		},
		{
			name: 	"monospaced by block",
			tip:    "block monospaced",
			syntax: "{{{\nuser_text\n}}}",
			hint:		"monospaced_text",
			byBlock: true,
			format: apl_wikibar_formatByLine
		},
		{
			name: 	"quote by line",
			tip:    "line quote",
			syntax: ">user_text",
			hint:		"quote_text",
			format: apl_wikibar_formatByLine
		},
		{
			name: 	"quote by block",
			tip:    "block quote",
			syntax: "<<<\nuser_text\n<<<",
			hint:		"quote_text",
			byBlock: true,			
			format: apl_wikibar_formatByLine
		}
  ],  // paragraphs
  links:[
		{
			name: 	"wiki",
			tip:    "wiki link",
			syntax: "[[user_text]]",
			hint:		"wiki_word",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"pretty",
			tip:    "pretty link",
			syntax: "[[user_text|%1]]", 
			hint:		"pretty_word",
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getLinkUrl,
			param:	"PrettyLink Target"
		},
		{
			name: 	"url",
			tip:    "url link",
			syntax: "[[user_text|%1]]", 
			hint:		"your_text",
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getLinkUrl,
			param:	"http://..."
		},
		{
			name: 	"image",
			tip:    "image link",
			syntax: "[img[user_text|%1]]", 
			hint:		"alt_text",
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getLinkUrl,
			param:	"image/icon.jpg"
		}
  ],  // links
  plugins:[
		{
			name: 	"codes area",
			tip:    "block monospaced for plugin",
			syntax: "//{{{\nuser_text\n//}}}",
			hint:		"monospaced_plugin_text",
			byBlock: true,
			format: apl_wikibar_formatByLine
		},  
		{
			name: 	"comment by line",
			tip:    "line comment",
			syntax: "//user_text",
			hint:		"plugin_comment",
			format: apl_wikibar_formatByLine
		},
		{
			name: 	"comment by block",
			tip:    "block comment",
			syntax: "/***\nuser_text\n***/",
			hint:		"plugin_comment",
			byBlock: true,
			format: apl_wikibar_formatByLine
		}
  ],  // plugins
  tables:[
		{
			name: 	"table",
			tip:    "create a new table",
			syntax: "\n%1\n",
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getTableRowCol
		},
		{
			name: 	"table header",
			tip:    "table header text",
			syntax: "|user_text|c",
			hint:		"table_header",
			format: apl_wikibar_formatByWord
		},		
		{
			name: 	"cell",
			tip:    "create a tabel cell",
			syntax: "|user_text|",
			hint:		"your_text",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"column header",
			tip:    "create a column header cell",
			syntax: "|!user_text|",
			hint:		"column_header",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"cell bgcolor",
			tip:    "cell bgcolor",
			syntax: "|bgcolor(%1):user_text|",
			hint:		"your_text",
			format: apl_wikibar_formatByTableCell,
			needParam: apl_wikibar_getColorCode
		},
		{
			name: 	"align left",
			tip:    "add a tabel cell",
			syntax: "|user_text|",
			hint:		"your_text",
			format: apl_wikibar_formatByTableCell
		},
		{
			name: 	"align center",
			tip:    "add a tabel cell",
			syntax: "| user_text |",
			hint:		"your_text",
			format: apl_wikibar_formatByTableCell
		},
		{
			name: 	"align right",
			tip:    "add a tabel cell",
			syntax: "| user_text|",
			hint:		"your_text",
			format: apl_wikibar_formatByTableCell
		}
  ],  // tables
  macros:[
		{
			name: 	"allTags",
			tip:    "allTags",
			syntax: "<<allTags>>",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"closeAll",
			tip:    "closeAll",
			syntax: "<<closeAll>>",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"gradient",
			tip:    "gradient",
			syntax: "<<gradient vert #ffffff %1>>user_text>>",
			format: apl_wikibar_formatByWord,
      needParam: apl_wikibar_getColorCode
		},
		{
			name: 	"list",
			tip:    "list",
			syntax: "<<list>>",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"list missing",
			tip:    "list missing",
			syntax: "<<list missing>>",
			format: apl_wikibar_formatByWord
		},
		{
			name: 	"list orphans",
			tip:    "list orphans",
			syntax: "<<list orphans>>",
			format: apl_wikibar_formatByWord
		},		
		{
			name: 	"newJournal",
			tip:    "newJournal",
			syntax: "<<newJournal>>",
			format: apl_wikibar_formatByWord
		},		
		{
			name: 	"newTiddler",
			tip:    "newTiddler",
			syntax: "<<newTiddler>>",
			format: apl_wikibar_formatByWord
		},		
		{
			name: 	"option",
			tip:    "option",
			syntax: "<<option %1>>[%2]\n",
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getMacroParam,
			param: 	'chkOpenInNewWindow "Open link in new window"'
		},		
		{
			name: 	"permaview",
			tip:    "permaview",
			syntax: "<<permaview>>",
			format: apl_wikibar_formatByWord
		},		
		{
			name: 	"saveChanges",
			tip:    "saveChanges",
			syntax: "<<saveChanges>>",
			format: apl_wikibar_formatByWord
		},		
		{
			name: 	"search",
			tip:    "search",
			syntax: "<<search>>",
			format: apl_wikibar_formatByWord
		},		
		{
			name: 	"slider",
			tip:    "slider",
			syntax: "<<slider %1 %2 %3>>",
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getMacroParam,
			param: 	"sliderID sliderTiddler sliderLabel"
		},		
		{
			name: 	"sparkline",
			tip:    "sparkline",
			syntax: "<<sparkline %N>>", 
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getMacroParam,
			param:	"number_list(ex: 100 123 ...)"
		},		
		{
			name: 	"tabs",
			tip:    "tabs",
			syntax: "<<tabs [%N]>>",
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getMacroParam,
			param: 	"indentifier tabLabel tabName Tiddler"
		},		
		{
			name: 	"tag",
			tip:    "tag",
			syntax: "<<tag %1>>",
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getMacroParam,
			param: 	"tagName(ex: systemConfig)"
		},		
		{
			name: 	"tiddler",
			tip:    "tiddler",
			syntax: "<<tiddler %1>>",
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getMacroParam,
			param: 	"Tiddler"
		},		
		{
			name: 	"timeline",
			tip:    "timeline",
			syntax: "<<timeline>>",
			format: apl_wikibar_formatByWord
		},		
		{
			name: 	"today",
			tip:    "today",
			syntax: "<<today [%1]>>", 
			format: apl_wikibar_formatByWord,
			needParam: apl_wikibar_getMacroParam,
			param:  '"YYYY/MM/DD hh:mm:ss"'
		},		
		{
			name: 	"version",
			tip:    "version",
			syntax: "<<version>>",
			format: apl_wikibar_formatByWord
		}
  ], // macros
  dates:[
    {
      name:   "YYYY",
      tip:    "full year",
      syntax: "YYYY",
      format: apl_wikibar_formatByCursor
    },
    {
      name:   "YY",
      tip:    "2-digit year",
      syntax: "YY",
      format: apl_wikibar_formatByCursor
    },
    {
      name:   "MMM",
      tip:    "month name",
      syntax: "MMM",
      format: apl_wikibar_formatByCursor
    },
    {
      name:   "MM",
      tip:    "month",
      syntax: "MM",
      format: apl_wikibar_formatByCursor
    },
    {
      name:   "0MM",
      tip:    "zero-leading month",
      syntax: "0MM",
      format: apl_wikibar_formatByCursor
    },
    {
      name:   "DDD",
      tip:    "week day",
      syntax: "DDD",
      format: apl_wikibar_formatByCursor
    },
    {
      name:   "DD",
      tip:    "day",
      syntax: "DD",
      format: apl_wikibar_formatByCursor
    },
    {
      name:   "0DD",
      tip:    "zero-leading day",
      syntax: "0DD",
      format: apl_wikibar_formatByCursor
    },
    {
      name:   "hh",
      tip:    "hour",
      syntax: "hh",
      format: apl_wikibar_formatByCursor
    },
    {
      name:   "mm",
      tip:    "minute",
      syntax: "mm",
      format: apl_wikibar_formatByCursor
    },
    {
      name:   "ss",
      tip:    "second",
      syntax: "ss",
      format: apl_wikibar_formatByCursor
    }    
  ], // dates
  htmls:[
		{
			name: 	"<html>",
			tip:    "html tag",
			syntax: "<html>\nuser_text\n</html>",
			hint:		"html_content",
			byBlock: true,
			format: apl_wikibar_formatByLine
		}
  ]	// htmls
};

/* style sheet */
setStylesheet('/* wikibar */ /* .wikibar .button {color:#59b; background:#eee} .wikibar .button:hover { color:#fff; background:#136; } */  /* aboutWikibar */ #aboutWikibar {position:absolute; z-index:10; background:#fff; border:2px solid red; }  /* previewer */ .previewer {overflow:auto; display:block; border:1px solid;}  /* colorPicker */ #colorPicker {position:absolute; display:none; z-index:10; margin:0px; padding:0px; } #colorPicker table {   margin:0px; padding:0px;   border:2px solid black;   border-spacing: 0px;   border-collapse: collapse; } #colorPicker td {margin:0px; padding:0px; border:1px solid; font-size:11px; text-align:center; cursor:auto;} #colorPicker .header {background: #fff;} #colorPicker .button {background: #fff; cursor:pointer; cursor:hand;} #colorPicker td.button:hover {padding-top:3px; padding-bottom:3px; color:#fff; background:#136;} #colorPicker .cell {padding:4px; font-size:7px; cursor:crosshair;} #colorPicker td.cell:hover {padding:10px;}  /* paletteSelector */ #paletteSelector {position:absolute; z-index:10; margin:0px; padding:0px;} #paletteSelector table {   margin:0px; padding:0px;   border:2px solid black;   border-spacing: 0px;   border-collapse: collapse; } #paletteSelector td {margin:0px; padding:1px; border:1px solid; font-size:11px; text-align:left; background: #fff; cursor:pointer; cursor:hand;} #paletteSelector td:hover {padding-top:3px; padding-bottom:3px; color:#fff; background:#136;} #paletteSelector .selected {background: #ff9;} #paletteSelector .unSelected {background: #fff;} #paletteSelector .button {text-align:center; background: #fff; }',
	'WikiBarStyleSheet'
);

/* event listener */
addEvent(document,"click", apl_wikibar_onDocumentClick);

//}}}